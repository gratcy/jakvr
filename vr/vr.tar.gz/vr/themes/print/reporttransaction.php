<html>
<title>Report Transaction</title>
<body>
            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">
<div class="box box-primary">

                                <!-- form start -->
                                    <div class="box-body">
									<h2 style="border-bottom:1px solid #000">JakVR - Report Transaction</h2>
									
									<table border="0" style="border-collapse: collapse;width:35%">
									<tr><td>Date</td><td>: <?php echo $post['datesort'];?></td></tr>
									<tr><td>Type</td><td>: <?php echo __get_transactions($post['type']); ?></td></tr>
									<tr><td>Format</td><td>: <?php echo __get_transaction_type($post['ttype'],1,2); ?></td></tr>
									<tr><td>Final</td><td>: <?php echo ($post['approval'] == 1 ? 'Yes' : ($post['approval'] == 2 ? 'All' : 'No')); ?></td></tr>
									</table>
									<br />
                                        <div class="form-group">
										<table border="0" style="border-collapse: collapse;width:100%">
										<thead>
										<tr style="border:1px solid #000;padding:3px;">
										<th style="border:1px solid #000;padding:3px;width:5%;">No.</th>
										<th style="border:1px solid #000;padding:3px;">Date</th>
										<th style="border:1px solid #000;padding:3px;">Trans No.</th>
										<th style="border:1px solid #000;padding:3px;">Descrpiton</th>
										<th style="border:1px solid #000;padding:3px;">Product</th>
										<th style="border:1px solid #000;padding:3px;">Price</th>
										<th style="border:1px solid #000;padding:3px;width:5%;">QTY</th>
										<th style="border:1px solid #000;padding:3px;">Bruto</th>
										<?php if (__get_roles('ProductPriceBase')) : ?>
										<th style="border:1px solid #000;padding:3px;">Netto</th>
										<?php endif; ?>
										</tr>
										</thead>
										<tbody>
										<?php
										$i = 1;
										$tgl = '';
										$tqty = 0;
										$tbruto = 0;
										$tnetto = 0;
										$tprice = 0;
										foreach($data as $k => $v) :
										?>
										<tr style="border:1px solid #000;padding:3px;">
										<td style="border:1px solid #000;padding:3px;"><?php echo $i; ?>.</td>
										<td style="border:1px solid #000;padding:3px;">
										<?php
										$date = __get_date($v -> tdate,1);
										if($tgl <> $date){
											$tgl = $date;
											echo $tgl;
										}
										?></td>
										<td style="border:1px solid #000;padding:3px;"><?php echo $v -> tno; ?></td>
										<td style="border:1px solid #000;padding:3px;"><?php echo $v -> tdesc; ?></td>
										<td style="border:1px solid #000;padding:3px;"><?php echo $v -> pname; ?></td>
										<td style="border:1px solid #000;padding:3px;text-align:right;"><?php echo __get_rupiah($v -> tprice,1); ?></td>
										<td style="border:1px solid #000;padding:3px;text-align:right;"><?php echo $v -> tqty; ?></td>
										<td style="border:1px solid #000;padding:3px;text-align:right;"><?php echo __get_rupiah($v -> tprice*$v -> tqty,1); ?></td>
										<?php if (__get_roles('ProductPriceBase')) : ?>
										<td style="border:1px solid #000;padding:3px;text-align:right;"><?php echo __get_rupiah(($v -> tprice - $v -> tpricebase)*$v -> tqty,1); ?></td>
										<?php endif; ?>
										</tr>
										<?php
										$tqty += $v -> tqty;
										$tprice += $v -> tprice;
										$tbruto += $v -> tprice*$v -> tqty;
										$tnetto += ($v -> tprice-$v->tpricebase)*$v -> tqty;
										++$i;
										endforeach;
										?>
										<tbody>
										<tfoot>
										<tr style="border:1px solid #000;">
											<th colspan="4" style="border:1px solid #000;padding:3px;">Total</th>
											<th style="border:1px solid #000;padding:3px;"></th>
											<th style="border:1px solid #000;padding:3px;text-align:right;"><?php echo __get_rupiah($tprice, 1); ?></th>
											<th style="border:1px solid #000;padding:3px;text-align:right;"><?php echo $tqty; ?></th>
											<th style="border:1px solid #000;padding:3px;text-align:right;"><?php echo __get_rupiah($tbruto, 1); ?></th>
										<?php if (__get_roles('ProductPriceBase')) : ?>
											<th style="border:1px solid #000;padding:3px;text-align:right;"><?php echo __get_rupiah($tnetto, 1); ?></th>
										<?php endif; ?>
										</tr>
										</tfoot>
										</table>
					
                                        </div>
                            </div>
                        </div>
                    </div>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->


</body>
</html>
